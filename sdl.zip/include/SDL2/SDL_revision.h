#define SDL_REVISION "https://github.com/libsdl-org/SDL.git@a1d1946dcba6509f0679f507b57e7b228d32e6f8"
#define SDL_REVISION_NUMBER 0
